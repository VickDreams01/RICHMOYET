# Richmoyet Fabrics & Enterprises — Website

Static, no-build website (plain HTML/CSS/JS). Nothing to compile or install.

## Run locally
Open `index.html` in a browser, or serve the folder:
    python3 -m http.server 8000   # then visit http://localhost:8000

## Structure
- `index.html`   Home + full catalogue (Fabrics / Bags / Shoes tabs, WhatsApp order buttons)
- `contact.html` Contact page
- `catalogue.html` Redirects to `index.html#collection`
- `styles.css`, `script.js` Shared styles and mobile-nav script
- `assets/logo.png` Brand logo
- `assets/images/` Product photos

## Common edits
- WhatsApp number: search `2348122124396` in `index.html` and `contact.html`.
- Add/replace a bag or shoe photo: drop the file in `assets/images/` and edit the matching `<img src="...">` in the Bags/Shoes panels of `index.html`.
- Fabric photo: edit the `<img>` inside that fabric card's `.swatch` div.

## Deploy
Upload the whole folder to any static host (Netlify, Vercel, GitHub Pages, cPanel).
